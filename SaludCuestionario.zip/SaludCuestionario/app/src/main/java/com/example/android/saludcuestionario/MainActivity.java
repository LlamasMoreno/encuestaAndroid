package com.example.android.saludcuestionario;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void submitOrder(View view) {
        String nombre = ((EditText)findViewById(R.id.nombre)).getText().toString();
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        int radioButtonID = radioGroup.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) radioGroup.findViewById(radioButtonID);
        String R1 = (String) radioButton.getText();

        RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.radioGroup2);
        int radioButtonID2 = radioGroup2.getCheckedRadioButtonId();
        RadioButton radioButton2 = (RadioButton) radioGroup2.findViewById(radioButtonID2);
        String R2 = (String) radioButton2.getText();

        RadioGroup radioGroup3 = (RadioGroup) findViewById(R.id.radioGroup3);
        int radioButtonID3 = radioGroup3.getCheckedRadioButtonId();
        RadioButton radioButton3 = (RadioButton) radioGroup3.findViewById(radioButtonID3);
        String R3 = (String) radioButton3.getText();

        RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.radioGroup4);
        int radioButtonID4 = radioGroup4.getCheckedRadioButtonId();
        RadioButton radioButton4 = (RadioButton) radioGroup4.findViewById(radioButtonID4);
        String R4 = (String) radioButton4.getText();

        RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.radioGroup5);
        int radioButtonID5 = radioGroup5.getCheckedRadioButtonId();
        RadioButton radioButton5 = (RadioButton) radioGroup5.findViewById(radioButtonID5);
        String R5 = (String) radioButton5.getText();

        RadioGroup radioGroup6 = (RadioGroup) findViewById(R.id.radioGroup6);
        int radioButtonID6 = radioGroup6.getCheckedRadioButtonId();
        RadioButton radioButton6 = (RadioButton) radioGroup6.findViewById(radioButtonID6);
        String R6 = (String) radioButton6.getText();

        RadioGroup radioGroup7 = (RadioGroup) findViewById(R.id.radioGroup7);
        int radioButtonID7 = radioGroup7.getCheckedRadioButtonId();
        RadioButton radioButton7 = (RadioButton) radioGroup7.findViewById(radioButtonID7);
        String R7 = (String) radioButton7.getText();

        RadioGroup radioGroup8 = (RadioGroup) findViewById(R.id.radioGroup8);
        int radioButtonID8 = radioGroup8.getCheckedRadioButtonId();
        RadioButton radioButton8 = (RadioButton) radioGroup8.findViewById(radioButtonID8);
        String R8 = (String) radioButton8.getText();

        RadioGroup radioGroup9 = (RadioGroup) findViewById(R.id.radioGroup9);
        int radioButtonID9 = radioGroup9.getCheckedRadioButtonId();
        RadioButton radioButton9 = (RadioButton) radioGroup9.findViewById(radioButtonID9);
        String R9 = (String) radioButton9.getText();

        RadioGroup radioGroup10 = (RadioGroup) findViewById(R.id.radioGroup10);
        int radioButtonID10 = radioGroup10.getCheckedRadioButtonId();
        RadioButton radioButton10 = (RadioButton) radioGroup10.findViewById(radioButtonID10);
        String R10 = (String) radioButton10.getText();

        String subj="Cuestionario de salud de:  "
                +nombre+".txt";
        String Text="1. ¿Cuántas ingestas de alimento se recomienda hacer al día?\n"+
                "Respuesta: "+R1 +"\n "
                +"\n2. ¿Cómo se calcula el IMC (Índice de masa corporal)?\n"+
                "Respuesta: "+R2 +"\n "
                +"\n3. ¿Qué tipo de dieta se recomienda para el tratamiento de la obesidad?\n"+
                "Respuesta: "+R3

                +"\n4. ¿Qué porcentaje de hidratos de carbono se recomienda en la dieta equilibrada para la obesidad? \n"+
                "Respuesta: "+R4 +"\n "

                +"\n5. ¿Qué porcentaje de proteínas se recomienda en la dieta equilibrada para la obesidad?\n"+
                "Respuesta: "+R5 +"\n "

                +"\n6. Qué porcentaje de grasas se recomienda en la dieta equilibrada para la obesidad?\n"+
                "Respuesta: "+R6 +"\n "

                +"\n7. ¿Cuál de las siguientes carnes aporta menos calorías por cada 100 gramos de alimento?\n"+
                "Respuesta: "+R7 +"\n "

                +"\n8. ¿Cuál de los siguientes alimentos aporta menos calorías por 100 gramos de alimento?\n"+
                "Respuesta: "+R8 +"\n "

                +"\n9. ¿Cuál de los siguientes alimentos se debe limitar en la dieta para la obesidad?\n"+
                "Respuesta: "+R9 +"\n "

                +"\n10. ¿Cuál de los siguientes lácteos aporta más calorías por 100 gramos de alimento? \n"+
                "Respuesta: "+R10 +"\n "

                ;
        String[] addr = {
                "yvesdaynel@gmail.com"
        };

        v1();
        String mail = "hello_gela@hotmail.com";
        String path = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS).getPath()+ subj;
        creardir(path);
        Escribir(path,Text);
        String path1 = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS).getPath();
        leer( path1,subj);
        AdjuntarMail( path,mail,subj);



        //crearAchivo(subj,Text);
        //AdjuntarMail(subj);


        //mandar();

        //openFile();
        //mailfile(Text);
        //writeToFile(data,context,fname);
        // CrearAchivo(fname,fContents );
        //writeStringAsFile(fContents,fname);
        //createDirIfNotExists("mydir/"); //Create a directory sdcard/mydir
        //createDirIfNotExists("mydir/myfile"); //Create a directory and a file in sdcard/mydir/myfile.txt

    }

    public boolean isStoragePermissionGranted() {
        String TAG = "Storage Permission";
        if (Build.VERSION.SDK_INT >= 23) {
            if (this.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.v(TAG, "Permission is granted");
                return true;
            } else {
                Log.v(TAG, "Permission is revoked");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            Log.v(TAG,"Permission is granted");
            return true;
        }
    }


    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /* Checks if external storage is available to at least read */
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }

    public void v1(){
        String v3 = String.valueOf(isStoragePermissionGranted());
        //Toast.makeText(this,v3 +" isStoragePermissionGranted()" ,Toast.LENGTH_LONG).show();
    }

    public void creardir(String path){
        File file = new File(path);
        //Toast.makeText(this, "ruta: "+path,Toast.LENGTH_LONG).show();
        if (!file.exists()) {
            try {

                file.createNewFile();
               // Toast.makeText(this, path,Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                Toast.makeText(this, path +" - "+e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
    }

    public void Escribir(String path,String data){
        File file = new File(path);
        FileOutputStream os = null;
        try {
            os = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
       // String data = "GRACIAS -------------------------------------------------------------------";
        try {
            os.write(data.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void leer(String path,String archivo){
        //Get the text file
        File file = new File(path,archivo);

//Read text from file
        StringBuilder text = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
            Toast.makeText(this, e.getMessage(),Toast.LENGTH_LONG).show();

        }
        Toast.makeText(this, path +" - "+text,Toast.LENGTH_LONG).show();
    }

    public boolean createDirIfNotExists(String path) {
        boolean ret = true;

        File file = new File(Environment.getExternalStorageDirectory(), path);
        if (!file.exists()) {
            Toast.makeText(this, "NO EXIXTE",Toast.LENGTH_LONG).show();

            if (!file.mkdirs()) {
                Toast.makeText(this, "Problem creating Image folder",Toast.LENGTH_LONG).show();

                Log.e("TravellerLog :: ", "Problem creating Image folder");
                ret = false;
                String DB_PATH = "/data/data/com.myawesomeapp.app/";

                File dbdir = new File(DB_PATH);
                dbdir.mkdirs();
                File file2 = new File(Environment.getExternalStorageDirectory(), DB_PATH);
                if (file2.exists()) {
                    Toast.makeText(this, "si EXIXTE",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(this, "siermpre no EXIXTE",Toast.LENGTH_LONG).show();
                }
            }else {
                String DB_PATH = "/sdcard/Android/data/com.myawesomeapp.app/";

                File dbdir = new File(DB_PATH);
                dbdir.mkdirs();
                File file2 = new File(Environment.getExternalStorageDirectory(), DB_PATH);
                if (!file2.exists()) {
                    Toast.makeText(this, "si EXIXTE",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(this, "siermpre no EXIXTE",Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this, "EXIXTE",Toast.LENGTH_LONG).show();



        }
        return ret;
    }




    public void crearAchivo(String nameArchivo,String mensaje ){
        File folder = new File(Environment.getExternalStorageDirectory() + "/TUTORIAL");
        folder.mkdir();
        if (folder.exists()) {
            Toast.makeText(this, "Creando directorio", Toast.LENGTH_SHORT).show();
            folder.mkdir();
        }
        //String nameArchivo = NombreArchivo.getText().toString();
        File archivo = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "/TUTORIAL/" + nameArchivo);


        try {
            FileOutputStream salvar = new FileOutputStream(archivo);
            salvar.write(mensaje.getBytes());
            salvar.close();
            Toast.makeText(this, "Archivo salvado", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "Archivo no salvado", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    public void AdjuntarMail(String path,String mail,String subject){

        try{

            String[] TO = {mail};
            String[] CC = {""};
            Uri uri = Uri.fromFile(new File(path));
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setData(Uri.parse("mailto:")); // only email apps should handle this
            intent.setType("plain/text");
            intent.putExtra(Intent.EXTRA_EMAIL, TO);
            intent.putExtra(Intent.EXTRA_CC, CC);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);
            intent.putExtra(android.content.Intent.EXTRA_TEXT, subject);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(Intent.createChooser(intent, "Send email using:"));
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }

        }catch (Exception e){
            e.printStackTrace();

        }
    }

    public File creardirectorio(String nombre){
        File directorio = new File(Environment.getExternalStorageDirectory()+nombre);
        if(!directorio.exists()){
            System.out.println("DIR NO EXISTE");
            directorio.mkdir();
        }
        File archivo = new File(directorio , "text.txt");
        return archivo;
    }

    public void MandarMail(String mail,String mensaje){
        String nomb = "/Cuestionario";
        File archivo =  creardirectorio(nomb);


        try{
            System.out.println("WRITE ATCHIVO");
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(archivo));
            outputStreamWriter.write(mensaje);
            outputStreamWriter.close();
        }catch (Exception error){
            Log.e("Error","Al generar el archivo");
        }

        //Obtiene la Uri del recurso.
        Uri uri = Uri.fromFile(new File(Environment.getExternalStorageDirectory()+ "/Cuestionario/" +"text.txt" ));
        //Crea intent para enviar el email.
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("*/*");
        //Agrega email o emails de destinatario.
        i.putExtra(Intent.EXTRA_EMAIL, mail);
        i.putExtra(Intent.EXTRA_SUBJECT, "Envio de archivo .TXT.");
        i.putExtra(Intent.EXTRA_TEXT, "Hola te envío un archivo .TXT!");
        i.putExtra(Intent.EXTRA_STREAM,  uri);
        if(i.resolveActivity(getPackageManager())!=null){
            //startActivity(Intent.createChooser(i, "Enviar e-mail mediante:"));
            // startActivity(i);
        }

        System.out.println("is exception raises during sending mail");

    }

    private void openFile() {
        File file = new File(Environment.getExternalStorageDirectory(),
                "Report.pdf");
        Uri path = Uri.fromFile(file);
        Intent pdfOpenintent = new Intent(Intent.ACTION_VIEW);
        pdfOpenintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        pdfOpenintent.setDataAndType(path, "application/pdf");
        try {
            startActivity(pdfOpenintent);
        }
        catch (ActivityNotFoundException e) {

        }


    }

    // Check whether the external storage is mounted or not.
    public static boolean isExternalStorageMounted() {

        String dirState = Environment.getExternalStorageState();
        if(Environment.MEDIA_MOUNTED.equals(dirState))
        {
            return true;
        }else
        {
            return false;
        }
    }

    // Get private external storage base directory.
    public static String getPrivateExternalStorageBaseDir(Context context, String dirType)
    {
        String ret = "";
        if(isExternalStorageMounted()) {
            File file = context.getExternalFilesDir(dirType);
            ret = file.getAbsolutePath();
        }
        return ret;
    }



    public static final boolean FORCED_LOGGING = true;
    private static final int CALLER_STACK_INDEX = 3;

    public static void showLogs(String message) {
        if (FORCED_LOGGING) {
            StackTraceElement caller = Thread.currentThread().getStackTrace()[CALLER_STACK_INDEX];

            String fullClassName = caller.getClassName();
            String className = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
            String methodName = caller.getMethodName();
            int lineNumber = caller.getLineNumber();

            Log.i("*** " + className + "." + methodName + "():" + lineNumber + "\n" , message);
        }
    }

    public void mandar(){
        String privateDirPath = getPrivateExternalStorageBaseDir(getApplicationContext(), null);
        String archivoTXT = "NewTextFile.txt";
        showLogs(privateDirPath);

        //Obtiene la Uri del recurso.
        Uri uri = Uri.fromFile(new File(privateDirPath, archivoTXT ));
        //Crea intent para enviar el email.
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        //Agrega email o emails de destinatario.
        i.putExtra(Intent.EXTRA_EMAIL, new String[] { "email@dominio.com" });
        i.putExtra(Intent.EXTRA_SUBJECT, "Envio de archivo .TXT.");
        i.putExtra(Intent.EXTRA_TEXT, "Hola te envío un archivo .TXT!");
        i.putExtra(Intent.EXTRA_STREAM,  uri);
        startActivity(Intent.createChooser(i, "Enviar e-mail mediante:"));
    }

    public void write(Context context, String filename ){
        File file = new File(context.getFilesDir(), filename);
    }

    public void mailfile(String message){
        try {
            String filelocation="/data/data/com.llamas.salud/files/Cuestionario de salud de:  profe2";
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse( "file://"+filelocation));
            intent.putExtra(Intent.EXTRA_TEXT, message);
            intent.setData(Uri.parse("mailto:"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(intent);
            finish();
        } catch(Exception e)  {
            System.out.println("is exception raises during sending mail"+e);
        }
    }

    public  void writeStringAsFile(final String fileContents, String fileName) {
        String nomb = "/Cuestionario";
        File archivo =  creardirectorio(nomb);
        try {
            FileWriter out = new FileWriter(new File(archivo, fileName));
            out.write(fileContents);
            out.close();
        } catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    private void writeToFile(String data,Context context,String fname) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(fname, Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    public void CrearAchivo(String fname, String fContents ){
        String filename = fname;
        String fileContents = fContents;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename,MODE_APPEND);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
            Toast.makeText(this, "cre EXIXTE",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    public void composeEmail(String[] addresses, String subject, String Text) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, Text);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}
